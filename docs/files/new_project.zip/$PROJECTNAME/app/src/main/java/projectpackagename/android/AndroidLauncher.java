package $PROJECTPACKAGENAME.android;

import $PROJECTPACKAGENAME.game.$PROJECTNAME;
import com.jme3.app.AndroidHarness;

public class AndroidLauncher extends AndroidHarness {

    public AndroidLauncher() {
        appClass = $PROJECTNAME.class.getCanonicalName();
    }
}
